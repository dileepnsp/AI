# ============================================================
#  postgres_mcp_server.py
#  FastMCP server for Employee & Department PostgreSQL tables
#  Read-only: Tools (dynamic queries) + Resources (schema/snapshots) + Prompts
# ============================================================

import json
import asyncpg                          # pip install asyncpg
from fastmcp import FastMCP             # pip install fastmcp
from typing import Optional

# ── Connection config ─────────────────────────────────────────────────────────
DB_CONFIG = {
    "host":     "localhost",
    "port":     5432,
    "database": "company_db",
    "user":     "readonly_user",
    "password": "your_password",
}

# Seed SQL so you can run this locally right away
SEED_SQL = """
CREATE TABLE IF NOT EXISTS department (
    dept_id     SERIAL PRIMARY KEY,
    dept_name   VARCHAR(100) NOT NULL,
    location    VARCHAR(100),
    budget      NUMERIC(15,2),
    created_at  TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS employee (
    emp_id      SERIAL PRIMARY KEY,
    first_name  VARCHAR(50)  NOT NULL,
    last_name   VARCHAR(50)  NOT NULL,
    email       VARCHAR(150) UNIQUE NOT NULL,
    dept_id     INTEGER REFERENCES department(dept_id),
    job_title   VARCHAR(100),
    salary      NUMERIC(12,2),
    hire_date   DATE,
    is_active   BOOLEAN DEFAULT TRUE
);

INSERT INTO department (dept_name, location, budget) VALUES
  ('Engineering',  'Singapore', 5000000),
  ('Marketing',    'Singapore', 2000000),
  ('HR',           'Singapore', 1000000),
  ('Finance',      'Singapore', 3000000)
ON CONFLICT DO NOTHING;

INSERT INTO employee (first_name, last_name, email, dept_id, job_title, salary, hire_date) VALUES
  ('Alice',  'Tan',    'alice@company.com',  1, 'Senior Engineer',    95000, '2021-03-15'),
  ('Bob',    'Lim',    'bob@company.com',    1, 'ML Engineer',        90000, '2022-07-01'),
  ('Carol',  'Wong',   'carol@company.com',  2, 'Marketing Manager',  80000, '2020-11-20'),
  ('David',  'Kumar',  'david@company.com',  3, 'HR Specialist',      65000, '2023-01-10'),
  ('Eve',    'Chen',   'eve@company.com',    4, 'Finance Analyst',    75000, '2021-08-05'),
  ('Frank',  'Ng',     'frank@company.com',  1, 'Junior Engineer',    70000, '2023-06-01')
ON CONFLICT DO NOTHING;
"""

# ── Helpers ───────────────────────────────────────────────────────────────────
async def get_conn():
    """Return a single asyncpg connection (read-only)."""
    conn = await asyncpg.connect(**DB_CONFIG)
    await conn.execute("SET SESSION CHARACTERISTICS AS TRANSACTION READ ONLY;")
    return conn


def rows_to_markdown(rows: list[asyncpg.Record]) -> str:
    """Convert asyncpg rows → readable markdown table string."""
    if not rows:
        return "No rows returned."
    headers = list(rows[0].keys())
    header_line  = " | ".join(headers)
    divider_line = " | ".join(["---"] * len(headers))
    data_lines   = [" | ".join(str(r[h]) for h in headers) for r in rows]
    return "\n".join([header_line, divider_line] + data_lines)


def assert_read_only(sql: str) -> None:
    """Raise if query contains write keywords."""
    forbidden = {"insert", "update", "delete", "drop", "truncate", "create", "alter", "grant"}
    tokens = set(sql.lower().split())
    bad = forbidden & tokens
    if bad:
        raise ValueError(f"Write operation not allowed: {bad}")


# ── FastMCP server ────────────────────────────────────────────────────────────
mcp = FastMCP(
    name="postgres-company-server",
    instructions="Read-only access to employee and department data.",
)


# ════════════════════════════════════════════════════════════════════════════════
#  TOOLS  — LLM decides what to query dynamically
# ════════════════════════════════════════════════════════════════════════════════

@mcp.tool()
async def query_employees(
    dept_name:  Optional[str] = None,
    is_active:  Optional[bool] = None,
    min_salary: Optional[float] = None,
    max_salary: Optional[float] = None,
    job_title:  Optional[str] = None,
    limit:      int = 50,
) -> str:
    """
    Query the employee table with optional filters.

    Args:
        dept_name:  Filter by department name (e.g. 'Engineering')
        is_active:  Filter by active status (True/False)
        min_salary: Minimum salary filter
        max_salary: Maximum salary filter
        job_title:  Filter by job title (partial match)
        limit:      Max rows to return (default 50)

    Returns:
        Markdown table of matching employees with dept name joined.
    """
    conditions = []
    params     = []
    idx        = 1

    base_sql = """
        SELECT e.emp_id, e.first_name, e.last_name, e.email,
               d.dept_name, e.job_title, e.salary, e.hire_date, e.is_active
        FROM   employee e
        LEFT JOIN department d ON e.dept_id = d.dept_id
    """

    if dept_name:
        conditions.append(f"LOWER(d.dept_name) = LOWER(${idx})")
        params.append(dept_name); idx += 1

    if is_active is not None:
        conditions.append(f"e.is_active = ${idx}")
        params.append(is_active); idx += 1

    if min_salary is not None:
        conditions.append(f"e.salary >= ${idx}")
        params.append(min_salary); idx += 1

    if max_salary is not None:
        conditions.append(f"e.salary <= ${idx}")
        params.append(max_salary); idx += 1

    if job_title:
        conditions.append(f"LOWER(e.job_title) LIKE LOWER(${idx})")
        params.append(f"%{job_title}%"); idx += 1

    sql = base_sql
    if conditions:
        sql += " WHERE " + " AND ".join(conditions)
    sql += f" ORDER BY e.last_name LIMIT ${idx}"
    params.append(limit)

    conn = await get_conn()
    try:
        rows = await conn.fetch(sql, *params)
        return f"**Employees** ({len(rows)} rows)\n\n" + rows_to_markdown(rows)
    finally:
        await conn.close()


@mcp.tool()
async def query_departments(
    location:   Optional[str] = None,
    min_budget: Optional[float] = None,
) -> str:
    """
    Query the department table with optional filters.

    Args:
        location:   Filter by office location (e.g. 'Singapore')
        min_budget: Only show departments with budget >= this value

    Returns:
        Markdown table of departments with employee headcount.
    """
    conditions = []
    params     = []
    idx        = 1

    base_sql = """
        SELECT d.dept_id, d.dept_name, d.location, d.budget,
               COUNT(e.emp_id) AS headcount
        FROM   department d
        LEFT JOIN employee e ON d.dept_id = e.dept_id AND e.is_active = TRUE
        GROUP BY d.dept_id, d.dept_name, d.location, d.budget
    """

    having_clauses = []
    if location:
        conditions.append(f"LOWER(d.location) = LOWER(${idx})")
        params.append(location); idx += 1

    if min_budget is not None:
        conditions.append(f"d.budget >= ${idx}")
        params.append(min_budget); idx += 1

    sql = base_sql
    if conditions:
        sql = base_sql.replace(
            "GROUP BY", f"WHERE {' AND '.join(conditions)} GROUP BY"
        )
    sql += " ORDER BY d.dept_name"

    conn = await get_conn()
    try:
        rows = await conn.fetch(sql, *params)
        return f"**Departments** ({len(rows)} rows)\n\n" + rows_to_markdown(rows)
    finally:
        await conn.close()


@mcp.tool()
async def run_sql(query: str) -> str:
    """
    Run any custom read-only SQL query against employee/department tables.
    Use this for complex JOINs, aggregations, or analytics the other tools
    cannot express (e.g. avg salary per dept, tenure analysis).

    Args:
        query: A valid SELECT SQL statement. No writes allowed.

    Returns:
        Markdown table of query results.

    Example queries:
        SELECT dept_name, AVG(salary) AS avg_salary
        FROM employee e JOIN department d ON e.dept_id = d.dept_id
        GROUP BY dept_name ORDER BY avg_salary DESC;
    """
    assert_read_only(query)

    conn = await get_conn()
    try:
        rows = await conn.fetch(query)
        return f"**Query result** ({len(rows)} rows)\n\n" + rows_to_markdown(rows)
    except Exception as e:
        return f"SQL error: {e}"
    finally:
        await conn.close()


@mcp.tool()
async def get_employee_by_id(emp_id: int) -> str:
    """
    Fetch full details of a single employee by ID.

    Args:
        emp_id: The employee's primary key

    Returns:
        Full employee record with department info as JSON.
    """
    sql = """
        SELECT e.*, d.dept_name, d.location
        FROM   employee e
        LEFT JOIN department d ON e.dept_id = d.dept_id
        WHERE  e.emp_id = $1
    """
    conn = await get_conn()
    try:
        row = await conn.fetchrow(sql, emp_id)
        if not row:
            return f"No employee found with emp_id={emp_id}"
        return json.dumps(dict(row), default=str, indent=2)
    finally:
        await conn.close()


# ════════════════════════════════════════════════════════════════════════════════
#  RESOURCES  — Agent pre-loads these as background context before calling LLM
# ════════════════════════════════════════════════════════════════════════════════

@mcp.resource("postgres://schema")
async def get_full_schema() -> str:
    """
    Full schema of employee and department tables.
    Agent injects this before every LLM call so the LLM knows
    column names, types, and foreign keys without guessing.
    """
    sql = """
        SELECT table_name, column_name, data_type, is_nullable, column_default
        FROM   information_schema.columns
        WHERE  table_schema = 'public'
          AND  table_name IN ('employee', 'department')
        ORDER BY table_name, ordinal_position;
    """
    conn = await get_conn()
    try:
        rows = await conn.fetch(sql)
        schema: dict[str, list] = {}
        for r in rows:
            schema.setdefault(r["table_name"], []).append({
                "column":   r["column_name"],
                "type":     r["data_type"],
                "nullable": r["is_nullable"],
                "default":  r["column_default"],
            })
        lines = []
        for table, cols in schema.items():
            lines.append(f"## Table: {table}")
            for c in cols:
                nullable = "NULL" if c["nullable"] == "YES" else "NOT NULL"
                lines.append(f"  - {c['column']} ({c['type']}, {nullable})")
        return "\n".join(lines)
    finally:
        await conn.close()


@mcp.resource("postgres://tables/employee")
async def get_employee_snapshot() -> str:
    """
    Full snapshot of the employee table (all active employees).
    Agent loads this when the user is clearly asking about headcount,
    roster, or 'list all employees'-type questions.
    """
    conn = await get_conn()
    try:
        rows = await conn.fetch("""
            SELECT e.emp_id, e.first_name, e.last_name, e.email,
                   d.dept_name, e.job_title, e.salary, e.hire_date
            FROM   employee e
            LEFT JOIN department d ON e.dept_id = d.dept_id
            WHERE  e.is_active = TRUE
            ORDER BY e.last_name
        """)
        return f"Active employees ({len(rows)}):\n\n" + rows_to_markdown(rows)
    finally:
        await conn.close()


@mcp.resource("postgres://tables/department")
async def get_department_snapshot() -> str:
    """
    Full snapshot of the department table with headcount.
    Agent loads this when the user asks about departments or org structure.
    """
    conn = await get_conn()
    try:
        rows = await conn.fetch("""
            SELECT d.dept_id, d.dept_name, d.location, d.budget,
                   COUNT(e.emp_id) AS active_headcount
            FROM   department d
            LEFT JOIN employee e ON d.dept_id = e.dept_id AND e.is_active = TRUE
            GROUP BY d.dept_id, d.dept_name, d.location, d.budget
            ORDER BY d.dept_name
        """)
        return f"Departments ({len(rows)}):\n\n" + rows_to_markdown(rows)
    finally:
        await conn.close()


# ════════════════════════════════════════════════════════════════════════════════
#  PROMPTS  — System instructions the agent injects before calling the LLM
# ════════════════════════════════════════════════════════════════════════════════

@mcp.prompt()
def sql_analyst_prompt(db_name: str = "company_db") -> str:
    """
    System prompt that turns the LLM into a read-only SQL analyst.
    Agent fetches this once and uses it as the system message.
    Update here → all clients get the new version automatically.
    """
    return f"""You are a SQL analyst for the '{db_name}' database.

## Rules
- ONLY write SELECT queries. NEVER suggest INSERT, UPDATE, DELETE, DROP, TRUNCATE, or ALTER.
- Always JOIN employee with department on dept_id to show dept_name instead of dept_id.
- Format all query results as markdown tables.
- If a user asks for something that would require a write, politely decline and explain why.

## Available tables
- employee  (emp_id, first_name, last_name, email, dept_id, job_title, salary, hire_date, is_active)
- department (dept_id, dept_name, location, budget, created_at)

## Response style
- Lead with the answer in one sentence, then show the data table.
- If the query returns more than 20 rows, summarise key stats (min, max, avg) first.
- Always mention the row count returned.
"""


if __name__ == "__main__":
    mcp.run(transport="stdio")
    # For HTTP/SSE mode: mcp.run(transport="sse", host="0.0.0.0", port=8001)
