# MCP Servers — PostgreSQL + ADLS
## Project structure

```
.
├── postgres_mcp_server.py   # FastMCP server: employee + department tables
├── adls_mcp_server.py       # FastMCP server: ADLS order files
├── agent_client.py          # Agent that connects to both servers + calls Claude
├── requirements.txt
└── README.md
```

---

## Install

```bash
pip install fastmcp asyncpg anthropic pandas pyarrow \
            azure-storage-file-datalake azure-identity
```

---

## PostgreSQL setup

1. Create a read-only Postgres user:
```sql
CREATE USER readonly_user WITH PASSWORD 'your_password';
GRANT CONNECT ON DATABASE company_db TO readonly_user;
GRANT USAGE  ON SCHEMA public TO readonly_user;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO readonly_user;
```

2. Update `DB_CONFIG` in `postgres_mcp_server.py`:
```python
DB_CONFIG = {
    "host":     "localhost",
    "port":     5432,
    "database": "company_db",
    "user":     "readonly_user",
    "password": "your_password",
}
```

3. Seed the tables (run once):
```bash
python -c "
import asyncio, asyncpg
async def seed():
    conn = await asyncpg.connect(host='localhost', database='company_db',
                                  user='readonly_user', password='your_password')
    from postgres_mcp_server import SEED_SQL
    await conn.execute(SEED_SQL)
    await conn.close()
asyncio.run(seed())
"
```

---

## ADLS setup

1. Set Azure credentials (choose one):

**Option A — Azure CLI (local dev)**
```bash
az login
```

**Option B — environment variables**
```bash
export AZURE_CLIENT_ID="..."
export AZURE_CLIENT_SECRET="..."
export AZURE_TENANT_ID="..."
```

**Option C — Managed Identity (in Azure VM / AKS)**
No config needed — DefaultAzureCredential picks it up automatically.

2. Update `STORAGE_ACCOUNT` in `adls_mcp_server.py`:
```python
STORAGE_ACCOUNT = "companydatalake"   # your actual storage account name
```

3. ADLS folder layout expected:
```
abfss://orders@companydatalake.dfs.core.windows.net/
├── raw/
│   ├── year=2024/month=01/orders_2024_01.parquet
│   ├── year=2024/month=02/orders_2024_02.parquet
│   └── year=2024/month=03/orders_2024_03.parquet
├── processed/
│   ├── orders_summary.parquet
│   └── orders_by_region.parquet
└── meta/
    ├── data_dictionary.json
    └── folder_index.json
```

---

## Run the agent

```bash
export ANTHROPIC_API_KEY="sk-ant-..."
python agent_client.py
```

---

## What each file does

### postgres_mcp_server.py

| Primitive | Name | What it does |
|-----------|------|--------------|
| **Tool** | `query_employees` | Filter employees by dept, salary, title |
| **Tool** | `query_departments` | Filter departments by location, budget |
| **Tool** | `run_sql` | Run any custom SELECT query |
| **Tool** | `get_employee_by_id` | Fetch one employee by ID |
| **Resource** | `postgres://schema` | Full DB schema (tables + columns) |
| **Resource** | `postgres://tables/employee` | Snapshot of all active employees |
| **Resource** | `postgres://tables/department` | Snapshot of all departments |
| **Prompt** | `sql_analyst_prompt` | LLM system instructions for SQL work |

### adls_mcp_server.py

| Primitive | Name | What it does |
|-----------|------|--------------|
| **Tool** | `search_order_files` | Find files by path prefix / pattern |
| **Tool** | `read_order_file` | Preview N rows of any Parquet/CSV file |
| **Tool** | `query_orders_parquet` | Filter a Parquet file by column value |
| **Tool** | `get_order_stats` | Summary statistics for a Parquet file |
| **Resource** | `adls://orders/containers` | Top-level ADLS folder structure |
| **Resource** | `adls://orders/meta/data-dictionary` | Column definitions for order files |
| **Resource** | `adls://orders/meta/folder-index` | Full file index with sizes & dates |
| **Prompt** | `data_analyst_prompt` | LLM system instructions for ADLS work |

---

## Use as Claude Desktop tools

Add both servers to `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "postgres-company": {
      "command": "python",
      "args": ["/path/to/postgres_mcp_server.py"]
    },
    "adls-orders": {
      "command": "python",
      "args": ["/path/to/adls_mcp_server.py"]
    }
  }
}
```

Restart Claude Desktop — both servers appear automatically in the tools panel.
