# ============================================================
#  adls_mcp_server.py
#  FastMCP server for Azure Data Lake Storage (ADLS Gen2)
#  Order details stored at:
#    abfss://orders@companydatalake.dfs.core.windows.net/
#  Read-only: Tools (dynamic file ops) + Resources (index/dict) + Prompts
# ============================================================

import io
import json
import pandas as pd                                    # pip install pandas pyarrow
from azure.storage.filedatalake import DataLakeServiceClient   # pip install azure-storage-file-datalake
from azure.identity import DefaultAzureCredential             # pip install azure-identity
from fastmcp import FastMCP
from typing import Optional

# ── ADLS connection config ────────────────────────────────────────────────────
STORAGE_ACCOUNT   = "companydatalake"
ACCOUNT_URL       = f"https://{STORAGE_ACCOUNT}.dfs.core.windows.net"

# Container (filesystem) and root path for all order data
ORDERS_CONTAINER  = "orders"

# Full ADLS path layout:
#   abfss://orders@companydatalake.dfs.core.windows.net/
#   ├── raw/
#   │   ├── year=2024/month=01/orders_2024_01.parquet
#   │   ├── year=2024/month=02/orders_2024_02.parquet
#   │   └── year=2024/month=03/orders_2024_03.parquet
#   ├── processed/
#   │   ├── orders_summary.parquet
#   │   └── orders_by_region.parquet
#   └── meta/
#       ├── data_dictionary.json
#       └── folder_index.json

# ── Auth — uses DefaultAzureCredential (env vars / managed identity / CLI) ───
def get_adls_client() -> DataLakeServiceClient:
    credential = DefaultAzureCredential()
    return DataLakeServiceClient(account_url=ACCOUNT_URL, credential=credential)


def get_filesystem_client():
    return get_adls_client().get_file_system_client(ORDERS_CONTAINER)


# ── Helper: read any file from ADLS into bytes ────────────────────────────────
def read_adls_file_bytes(path: str) -> bytes:
    """
    path: relative path within the ORDERS_CONTAINER
    e.g. "raw/year=2024/month=01/orders_2024_01.parquet"
    """
    fs     = get_filesystem_client()
    client = fs.get_file_client(path)
    stream = client.download_file()
    return stream.readall()


def parquet_preview(path: str, n_rows: int = 50) -> str:
    """Read a Parquet file from ADLS and return first N rows as markdown table."""
    raw    = read_adls_file_bytes(path)
    df     = pd.read_parquet(io.BytesIO(raw))
    sample = df.head(n_rows)
    stats  = (
        f"**Shape:** {df.shape[0]:,} rows × {df.shape[1]} columns\n"
        f"**Columns:** {', '.join(df.columns.tolist())}\n\n"
    )
    return stats + sample.to_markdown(index=False)


def csv_preview(path: str, n_rows: int = 50) -> str:
    """Read a CSV file from ADLS and return first N rows as markdown table."""
    raw    = read_adls_file_bytes(path)
    df     = pd.read_csv(io.BytesIO(raw), nrows=n_rows)
    return df.to_markdown(index=False)


def json_read(path: str) -> str:
    """Read a JSON file from ADLS and return as formatted string."""
    raw = read_adls_file_bytes(path)
    return json.dumps(json.loads(raw), indent=2)


# ── FastMCP server ────────────────────────────────────────────────────────────
mcp = FastMCP(
    name="adls-orders-server",
    instructions="Read-only access to order data stored in Azure Data Lake Storage.",
)


# ════════════════════════════════════════════════════════════════════════════════
#  TOOLS  — LLM decides which file/path/filter to use dynamically
# ════════════════════════════════════════════════════════════════════════════════

@mcp.tool()
def search_order_files(
    path_prefix: str = "",
    pattern:     str = "",
) -> str:
    """
    List files in the ADLS orders container matching an optional path prefix
    and/or filename pattern. Use to discover what order files exist.

    Full ADLS path: abfss://orders@companydatalake.dfs.core.windows.net/{path_prefix}

    Args:
        path_prefix: Subfolder to search in. Examples:
                     "raw/year=2024/month=03"
                     "processed"
                     "" (empty = list everything from root)
        pattern:     Filename substring filter, e.g. "parquet", "2024_01", "summary"

    Returns:
        List of matching file paths with sizes and last-modified dates.
    """
    fs    = get_filesystem_client()
    paths = fs.get_paths(path=path_prefix or "/", recursive=True)

    rows = []
    for p in paths:
        if p.is_directory:
            continue
        name = p.name
        if pattern and pattern.lower() not in name.lower():
            continue
        size_kb = round(p.content_length / 1024, 1) if p.content_length else 0
        rows.append(f"- `{name}` ({size_kb} KB, modified: {p.last_modified})")

    if not rows:
        return f"No files found under '{path_prefix}' matching '{pattern}'."
    return f"**Found {len(rows)} files:**\n\n" + "\n".join(rows)


@mcp.tool()
def read_order_file(
    path:   str,
    n_rows: int = 50,
) -> str:
    """
    Preview the first N rows of an order file (Parquet or CSV).

    Full ADLS path: abfss://orders@companydatalake.dfs.core.windows.net/{path}

    Args:
        path:   Relative path within the orders container. Examples:
                "raw/year=2024/month=01/orders_2024_01.parquet"
                "processed/orders_summary.parquet"
                "raw/year=2024/month=03/orders_2024_03.csv"
        n_rows: How many rows to preview (default 50, max 500)

    Returns:
        File shape, column names, and first N rows as a markdown table.
    """
    n_rows = min(n_rows, 500)

    if path.endswith(".parquet"):
        return parquet_preview(path, n_rows)
    elif path.endswith(".csv"):
        return csv_preview(path, n_rows)
    elif path.endswith(".json"):
        return json_read(path)
    else:
        raw = read_adls_file_bytes(path)
        return raw.decode("utf-8", errors="replace")[:4000]


@mcp.tool()
def query_orders_parquet(
    path:          str,
    filter_column: Optional[str] = None,
    filter_value:  Optional[str] = None,
    columns:       Optional[list[str]] = None,
    n_rows:        int = 100,
) -> str:
    """
    Load a Parquet order file and apply column/value filters in-memory.
    Use this when you need to slice order data by region, status, customer, etc.

    Full ADLS path: abfss://orders@companydatalake.dfs.core.windows.net/{path}

    Args:
        path:          Path to the Parquet file, e.g.
                       "raw/year=2024/month=01/orders_2024_01.parquet"
        filter_column: Column name to filter on, e.g. "region", "status", "customer_id"
        filter_value:  Value to match (exact string match), e.g. "APAC", "SHIPPED"
        columns:       List of columns to return, e.g. ["order_id","amount","status"]
                       Leave empty to return all columns.
        n_rows:        Max rows to return (default 100)

    Returns:
        Filtered rows as a markdown table with shape info.
    """
    raw = read_adls_file_bytes(path)
    df  = pd.read_parquet(io.BytesIO(raw), columns=columns or None)

    if filter_column and filter_value:
        if filter_column not in df.columns:
            return f"Column '{filter_column}' not found. Available: {df.columns.tolist()}"
        df = df[df[filter_column].astype(str).str.lower() == filter_value.lower()]

    shape_info = f"**Filtered shape:** {len(df):,} rows × {df.shape[1]} columns\n\n"
    return shape_info + df.head(n_rows).to_markdown(index=False)


@mcp.tool()
def get_order_stats(path: str) -> str:
    """
    Compute summary statistics (count, sum, mean, min, max) for all
    numeric columns in an order Parquet file. Useful for quick analytics
    without needing a full SQL engine.

    Full ADLS path: abfss://orders@companydatalake.dfs.core.windows.net/{path}

    Args:
        path: Relative path to a Parquet file, e.g.
              "processed/orders_summary.parquet"

    Returns:
        Descriptive statistics table + value counts for categorical columns.
    """
    raw = read_adls_file_bytes(path)
    df  = pd.read_parquet(io.BytesIO(raw))

    numeric_stats = df.describe().round(2).to_markdown()

    cat_cols   = df.select_dtypes(include="object").columns.tolist()
    cat_summary = []
    for col in cat_cols[:5]:                    # top 5 categorical columns only
        top = df[col].value_counts().head(5)
        cat_summary.append(
            f"\n**{col} — top values:**\n" +
            "\n".join(f"  {v}: {c:,}" for v, c in top.items())
        )

    return (
        f"**File:** `{path}`\n"
        f"**Total rows:** {len(df):,}\n\n"
        f"### Numeric statistics\n{numeric_stats}\n"
        + "".join(cat_summary)
    )


# ════════════════════════════════════════════════════════════════════════════════
#  RESOURCES  — Agent pre-loads these as background context before calling LLM
# ════════════════════════════════════════════════════════════════════════════════

@mcp.resource("adls://orders/containers")
def list_top_level_folders() -> str:
    """
    Top-level folder structure of the orders container.

    Full ADLS root: abfss://orders@companydatalake.dfs.core.windows.net/

    Agent injects this before the LLM runs so the LLM knows the folder
    layout without having to call search_order_files first.
    """
    fs    = get_filesystem_client()
    paths = fs.get_paths(path="/", recursive=False)

    lines = [
        "# ADLS orders container structure",
        f"# Root: abfss://orders@{STORAGE_ACCOUNT}.dfs.core.windows.net/",
        "",
    ]
    for p in paths:
        icon = "📁" if p.is_directory else "📄"
        lines.append(f"{icon} {p.name}")

    # Also list one level deep
    lines.append("\n## Detailed layout")
    for p in paths:
        if p.is_directory:
            sub = fs.get_paths(path=p.name, recursive=False)
            for s in sub:
                lines.append(f"  {'📁' if s.is_directory else '📄'} {s.name}")
    return "\n".join(lines)


@mcp.resource("adls://orders/meta/data-dictionary")
def get_data_dictionary() -> str:
    """
    Column-level data dictionary for all order Parquet files.
    Describes what each column means so the LLM can answer
    questions without guessing field semantics.

    Loaded from: abfss://orders@companydatalake.dfs.core.windows.net/meta/data_dictionary.json
    If the file doesn't exist yet, a hardcoded dictionary is returned.
    """
    try:
        return json_read("meta/data_dictionary.json")
    except Exception:
        # Fallback: inline dictionary (replace with your actual schema)
        dictionary = {
            "order_id":    "Unique order identifier (UUID)",
            "customer_id": "Foreign key to customer master table",
            "order_date":  "Date the order was placed (YYYY-MM-DD)",
            "ship_date":   "Date the order was shipped",
            "status":      "Order status: PENDING | PROCESSING | SHIPPED | DELIVERED | CANCELLED",
            "region":      "Sales region: APAC | EMEA | AMER",
            "product_id":  "SKU of the ordered product",
            "quantity":    "Number of units ordered",
            "unit_price":  "Price per unit in USD",
            "amount":      "Total order value = quantity × unit_price",
            "discount":    "Discount applied (0.0 – 1.0)",
            "channel":     "Sales channel: ONLINE | RETAIL | B2B",
        }
        return json.dumps(dictionary, indent=2)


@mcp.resource("adls://orders/meta/folder-index")
def get_folder_index() -> str:
    """
    Full recursive index of every file in the orders container with size and
    last-modified date. Agent uses this to tell the LLM exactly which
    Parquet files exist and when they were last updated.

    Generated from: abfss://orders@companydatalake.dfs.core.windows.net/
    """
    try:
        return json_read("meta/folder_index.json")
    except Exception:
        # Dynamically build the index if the static file doesn't exist
        fs    = get_filesystem_client()
        paths = fs.get_paths(path="/", recursive=True)
        index = []
        for p in paths:
            if not p.is_directory:
                index.append({
                    "path":          p.name,
                    "size_bytes":    p.content_length,
                    "last_modified": str(p.last_modified),
                })
        return json.dumps(index, indent=2)


# ════════════════════════════════════════════════════════════════════════════════
#  PROMPTS  — System instructions the agent injects before calling the LLM
# ════════════════════════════════════════════════════════════════════════════════

@mcp.prompt()
def data_analyst_prompt(lake_name: str = "companydatalake") -> str:
    """
    System prompt that turns the LLM into a read-only ADLS data analyst.
    Agent fetches this once and uses it as the system message.
    """
    return f"""You are a data analyst for the '{lake_name}' Azure Data Lake.

## Rules
- READ ONLY. Never suggest writing, deleting, or modifying files.
- All order data lives under: abfss://orders@{lake_name}.dfs.core.windows.net/
- Folder layout:
    raw/year=YYYY/month=MM/   → raw monthly Parquet files
    processed/                → aggregated summaries
    meta/                     → data dictionary, folder index

## Response style
- Always start with the file path and row count before showing data.
- Format all data as markdown tables.
- For large files (>10k rows) show summary statistics first, then sample rows.
- When the user asks "what orders..." always check the data dictionary first to
  understand column semantics before filtering.
- If a date range spans multiple monthly files, mention that the user
  may need to combine results from multiple files.
"""


if __name__ == "__main__":
    mcp.run(transport="stdio")
    # For HTTP/SSE mode: mcp.run(transport="sse", host="0.0.0.0", port=8002)
