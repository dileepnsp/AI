# ============================================================
#  agent_client.py
#  Agent that connects to BOTH MCP servers simultaneously
#  and uses Claude to answer questions across PostgreSQL + ADLS
# ============================================================

import asyncio
import anthropic
from fastmcp import Client

# ── Clients ───────────────────────────────────────────────────────────────────
llm = anthropic.Anthropic()           # uses ANTHROPIC_API_KEY env var

PG_SERVER   = "postgres_mcp_server.py"   # local stdio
ADLS_SERVER = "adls_mcp_server.py"       # local stdio


# ════════════════════════════════════════════════════════════════════════════════
#  Helper: collect tools from one MCP client into Anthropic tool format
# ════════════════════════════════════════════════════════════════════════════════
async def collect_tools(client: Client, prefix: str = "") -> list[dict]:
    """
    Fetch tool schemas from an MCP server and convert to Anthropic format.
    prefix: optional tag to avoid name collisions if two servers have same tool name
    """
    tools = await client.list_tools()
    return [
        {
            "name":         f"{prefix}{t.name}" if prefix else t.name,
            "description":  t.description or "",
            "input_schema": t.inputSchema or {"type": "object", "properties": {}},
        }
        for t in tools
    ]


# ════════════════════════════════════════════════════════════════════════════════
#  Core agent loop
# ════════════════════════════════════════════════════════════════════════════════
async def run_agent(user_question: str) -> str:
    """
    Full agent turn:
      1. Pre-load resources (schema, folder index) as context
      2. Fetch prompt templates from both servers
      3. Collect all tool schemas
      4. Call Claude with context + tools
      5. Execute any tool_use blocks via MCP
      6. Return final answer
    """
    print(f"\n{'='*60}")
    print(f"User: {user_question}")
    print('='*60)

    async with (
        Client(PG_SERVER)   as pg,
        Client(ADLS_SERVER) as adls,
    ):

        # ── Step 1: Pre-load resources ─────────────────────────────────────────

        print("\n[1] Loading resources...")

        # PostgreSQL resources
        pg_schema   = await pg.read_resource("postgres://schema")
        pg_emp_snap = await pg.read_resource("postgres://tables/employee")
        pg_dept_snap= await pg.read_resource("postgres://tables/department")

        # ADLS resources
        adls_folders = await adls.read_resource("adls://orders/containers")
        adls_dict    = await adls.read_resource("adls://orders/meta/data-dictionary")
        adls_index   = await adls.read_resource("adls://orders/meta/folder-index")

        pg_schema_text    = pg_schema[0].text
        pg_emp_text       = pg_emp_snap[0].text
        pg_dept_text      = pg_dept_snap[0].text
        adls_folders_text = adls_folders[0].text
        adls_dict_text    = adls_dict[0].text
        adls_index_text   = adls_index[0].text

        print("  ✓ PostgreSQL schema, employee snapshot, department snapshot")
        print("  ✓ ADLS folder index, data dictionary, folder listing")

        # ── Step 2: Fetch prompts from both servers ────────────────────────────

        print("\n[2] Fetching prompt templates...")

        pg_prompt   = await pg.get_prompt("sql_analyst_prompt",   {"db_name": "company_db"})
        adls_prompt = await adls.get_prompt("data_analyst_prompt", {"lake_name": "companydatalake"})

        system_prompt = (
            pg_prompt.messages[0].content.text
            + "\n\n---\n\n"
            + adls_prompt.messages[0].content.text
        )
        print("  ✓ sql_analyst_prompt + data_analyst_prompt merged")

        # ── Step 3: Collect all tools from both servers ────────────────────────

        print("\n[3] Collecting tools...")

        pg_tools   = await collect_tools(pg,   prefix="pg_")
        adls_tools = await collect_tools(adls, prefix="adls_")
        all_tools  = pg_tools + adls_tools

        print(f"  ✓ {len(pg_tools)} PostgreSQL tools + {len(adls_tools)} ADLS tools")
        for t in all_tools:
            print(f"     • {t['name']}")

        # ── Step 4: Build context block + call Claude ──────────────────────────

        context_block = f"""
## PostgreSQL context (pre-loaded)

### Database schema
{pg_schema_text}

### Current employees
{pg_emp_text}

### Departments
{pg_dept_text}

---

## ADLS context (pre-loaded)

### Folder structure
{adls_folders_text}

### Data dictionary (column definitions)
{adls_dict_text}

### File index
{adls_index_text}
""".strip()

        messages = [
            {
                "role":    "user",
                "content": f"{context_block}\n\n---\n\nUser question: {user_question}",
            }
        ]

        print("\n[4] Calling Claude...")

        # Agentic loop — Claude may call multiple tools in sequence
        iteration = 0
        max_iter  = 10

        while iteration < max_iter:
            iteration += 1

            response = llm.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=4096,
                system=system_prompt,
                tools=all_tools,
                messages=messages,
            )

            print(f"\n  Claude response (iter {iteration}): stop_reason={response.stop_reason}")

            # Collect text and tool_use blocks
            tool_calls  = [b for b in response.content if b.type == "tool_use"]
            text_blocks = [b for b in response.content if b.type == "text"]

            for b in text_blocks:
                print(f"  Claude says: {b.text[:120]}...")

            if response.stop_reason == "end_turn" or not tool_calls:
                # Done — assemble final text answer
                final = "\n\n".join(b.text for b in text_blocks)
                return final

            # ── Step 5: Execute all tool calls via the right MCP server ───────
            print(f"\n[5] Executing {len(tool_calls)} tool call(s)...")

            # Add Claude's response to message history
            messages.append({"role": "assistant", "content": response.content})

            tool_results = []
            for tc in tool_calls:
                print(f"  → Calling tool: {tc.name}  args={tc.input}")

                # Route to the right server based on prefix
                if tc.name.startswith("pg_"):
                    real_name = tc.name[3:]          # strip "pg_" prefix
                    result    = await pg.call_tool(real_name, tc.input)
                elif tc.name.startswith("adls_"):
                    real_name = tc.name[5:]          # strip "adls_" prefix
                    result    = await adls.call_tool(real_name, tc.input)
                else:
                    result = [type("R", (), {"text": f"Unknown tool: {tc.name}"})()]

                result_text = result[0].text if result else "No result"
                print(f"     ← Result: {result_text[:100]}...")

                tool_results.append({
                    "type":        "tool_result",
                    "tool_use_id": tc.id,
                    "content":     result_text,
                })

            # Feed tool results back to Claude
            messages.append({"role": "user", "content": tool_results})

        return "Agent reached max iterations without a final answer."


# ════════════════════════════════════════════════════════════════════════════════
#  Example questions
# ════════════════════════════════════════════════════════════════════════════════
EXAMPLE_QUESTIONS = [

    # PostgreSQL — uses query_employees tool
    "Show me all employees in the Engineering department with salary above 85000.",

    # PostgreSQL — uses query_departments tool
    "Which department has the highest budget and how many active employees does it have?",

    # PostgreSQL — uses run_sql tool (complex join)
    "What is the average salary per department? Show results ordered by average salary descending.",

    # ADLS — uses search_order_files tool
    "What order files do we have for January 2024?",

    # ADLS — uses read_order_file + query_orders_parquet tools
    "Show me the first 20 rows of the January 2024 order file and filter for APAC region.",

    # ADLS — uses get_order_stats tool
    "Give me summary statistics for the processed orders summary file.",

    # Cross-server question — uses both PostgreSQL + ADLS tools
    "How many employees are in Engineering, and how many APAC orders do we have in Q1 2024?",
]


async def main():
    # Run one example — change the index or pass your own question
    question = EXAMPLE_QUESTIONS[0]
    answer   = await run_agent(question)

    print(f"\n{'='*60}")
    print("FINAL ANSWER:")
    print('='*60)
    print(answer)


if __name__ == "__main__":
    asyncio.run(main())
